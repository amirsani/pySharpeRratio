from sharpeRratio import estimateSNR
